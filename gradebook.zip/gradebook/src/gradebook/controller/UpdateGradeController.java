package gradebook.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import gradebook.data.GradeDAO;
import gradebook.data.UserDAO;
import gradebook.model.AllGrades;
import gradebook.model.Course;
import gradebook.model.Grade;
import gradebook.model.User;

@WebServlet("/UpdateGradeController")
public class UpdateGradeController extends HttpServlet {
	private static final long serialVersionUID = 5L;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		//validate action
		String url="/allStudentGrades.jsp";
		if(action.equalsIgnoreCase("updateGrade")){
			String utaID = request.getParameter("utaID");
			String newGrade = request.getParameter("letterGrade");
			Course course = (Course) session.getAttribute("currentCourse");
			//validate utaID, newGrade, course
			User student = UserDAO.getUserByUTAID(utaID);
			//validate student from db
			Grade grade = new Grade(student.getID(), course.getID(), newGrade);
			
			String gradeErrorMsg = grade.validateGrade();
			request.setAttribute("gradeErrorMsg", gradeErrorMsg);
			if(gradeErrorMsg.equals("")) {
				GradeDAO.updateGrade(grade);
			    ArrayList<AllGrades> allGradesList = GradeDAO.getAllGradesList(course.getID());
			    //validate this list from db
			    session.setAttribute("AllGradesList",allGradesList);
			}
			
		}

		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("AllGradesList");
			session.removeAttribute("gradeErrorMsg");
			url="/professorHome.jsp";
		}
		getServletContext().getRequestDispatcher(url).forward(request, response);			
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//error page
	}
}