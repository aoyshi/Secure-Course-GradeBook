package gradebook.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import gradebook.data.UserDAO;
import gradebook.model.User;
import gradebook.model.UserErrorMsgs;
import gradebook.validator.Validator;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(LoginController.class);
	private Validator validator;
       
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PropertyConfigurator.configure("C:\\Users\\Arunika\\workspace\\gradebook\\log4j.properties");
		validator = new Validator();
		String url = "/login.jsp";
		HttpSession oldSession = request.getSession(false); 
    	if (oldSession != null) { 
    		//create new session even if there was an old session 
    		oldSession.invalidate(); 
    		HttpSession newSession = request.getSession(true); 
    		
		    String action = request.getParameter("action");		
			//validate String action before processing
		    if(validator.validateAction(action)) {	    	
		    	url = "/login.jsp";
				if (action.equalsIgnoreCase("login")) {
					if (request.getParameter("loginBtn")!=null) {
						
						String netIDEntered = request.getParameter("netID");
						String passwordEntered = request.getParameter("password");		
							User user = new User(); 
							user.setNetID(netIDEntered);
							user.setPassword(passwordEntered);		
							UserErrorMsgs uErrorMsgs = new UserErrorMsgs();		
							user.authenticateUser(user, uErrorMsgs); //this validates un and pw
							newSession.setAttribute("User",user);
							newSession.setAttribute("errorMsgs",uErrorMsgs);
							if (uErrorMsgs.getErrorMsg().equals("")) { 
								//credentials are valid at this point
								user = UserDAO.getUser(netIDEntered);		
								//validate User object retrieved from database
								if(validator.validateUser(user)) {
									newSession.setAttribute("currentUser",user);
									//redirect to appropriate home page based on role
									String role = user.getRole();
									if(role.equals("Student")) {
										url = "/StudentController"; 
									}
									else if(role.equals("Professor")) {
										url = "/ProfessorController?action=viewCourseList";
									}
								}
								else {
									url="/error.jsp"; //redirect to error page if input validation failed for user from DB
								}
																				
							}
						}												
					}
				}
		        else {
		     	    url="/error.jsp"; //redirect to error page if input validation failed for session action variable
		        }
    	}
		getServletContext().getRequestDispatcher(url).forward(request, response);
	}


	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//send all GET requests to error page
		getServletContext().getRequestDispatcher("/error.jsp").forward(request, response);
	}
}