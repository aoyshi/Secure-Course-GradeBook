package gradebook.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import gradebook.data.CourseDAO;
import gradebook.data.GradeDAO;
import gradebook.model.AllGrades;
import gradebook.model.Course;
import gradebook.model.User;

@WebServlet("/ProfessorController")
public class ProfessorController extends HttpServlet {
	private static final long serialVersionUID = 4L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		//validate action
		String url = "/professorHome.jsp";

		if(action.equalsIgnoreCase("viewCourseList")) {
			//display all courses taught by current prof
			User professor = (User) session.getAttribute("currentUser");
			//validate user obj
			ArrayList<Course> profCourseList = CourseDAO.getProfessorCourseList(professor); 
			//validate course list from db
			session.setAttribute("Courses", profCourseList);			
		}
		else if(action.equalsIgnoreCase("selectCourse")) {
			url="/allStudentGrades.jsp";			
			String courseIDAsString = request.getParameter("courseID");
			//validate courseID
			int courseID = Integer.parseInt(courseIDAsString);
			Course course = CourseDAO.getCourse(courseID);
			//validate course from db
			session.setAttribute("currentCourse", course);
			ArrayList<AllGrades> allGradesList = GradeDAO.getAllGradesList(courseID);
			//validate this list from db
			session.setAttribute("AllGradesList",allGradesList);	
		}
						
		getServletContext().getRequestDispatcher(url).forward(request, response);			
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//error page
	}
}