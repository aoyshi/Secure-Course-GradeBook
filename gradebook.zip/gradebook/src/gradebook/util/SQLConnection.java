package gradebook.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class SQLConnection {
	private static String DB_DRIVER;
	private static String DB_CONNECTION;
	private static String DB_USER;
	private static String DB_PW; 
	private static SQLConnection single_instance = null;
	
	private SQLConnection() {		
		Properties prop = new Properties();
	    try {	    	
			prop.load(new FileInputStream("C:/Users/Arunika/Desktop/Configuration/config.properties"));
			DB_DRIVER = prop.getProperty("DB_DRIVER");
		    DB_CONNECTION = prop.getProperty("DB_CONNECTION");
		    DB_USER = prop.getProperty("DB_USER");
		    DB_PW = prop.getProperty("DB_PASSWORD");
		    		    
		} catch (FileNotFoundException e) {
			//todo: LOG THIS
		} catch (IOException e) {
			//TODO: LOG THIS
		}

	}
	public static synchronized SQLConnection getInstance() {
        if (single_instance == null)
        	single_instance = new SQLConnection();
        return single_instance;
	}

	public static Connection getDBConnection() {	
		Connection dbConnection = null;	 

		try {	 
			Class.forName(DB_DRIVER);	 
		} catch (ClassNotFoundException e) {
		}

		try {	 
			dbConnection = DriverManager.getConnection(DB_CONNECTION,DB_USER,DB_PW);
			dbConnection.setAutoCommit(false);
		} catch (SQLException e) {	    
		}	 
		return dbConnection;	 
	}
}