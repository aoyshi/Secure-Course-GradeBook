package gradebook.model;

import java.io.Serializable;

import javax.validation.constraints.Pattern;

public class AllGrades implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String firstName;
	private String lastName;
	private String utaID;
	@Pattern(regexp = "[A|B]")
	private String letterGrade;

	public AllGrades(String firstName, String lastName, String utaID, String letterGrade) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.utaID = utaID;
		this.letterGrade = letterGrade;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUtaID() {
		return utaID;
	}

	public void setUtaID(String utaID) {
		this.utaID = utaID;
	}

	public String getLetterGrade() {
		return letterGrade;
	}

	public void setLetterGrade(String letterGrade) {
		this.letterGrade = letterGrade;
	}	

}