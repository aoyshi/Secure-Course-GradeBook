package gradebook.model;

import java.io.Serializable;

public class UserErrorMsgs implements Serializable {
	
	private static final long serialVersionUID = 6L;
		
	private String errorMsg;
	private String netIDError;
	private String passwordError;
	
	public UserErrorMsgs () {
		this.errorMsg="";
		this.netIDError="";
		this.passwordError="";
	}
	
	public void setErrorMsg() {
		if (!netIDError.equals("") || !passwordError.equals(""))
		  errorMsg="Please correct the following errors";
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	
	public String getNetIDError() {
		return netIDError;
	}
	public void setNetIDError(String netIDError) {
		this.netIDError = netIDError;
	}	
	
	public String getPasswordError() {
		return passwordError;
	}
	public void setPasswordError(String passwordError) {
		this.passwordError = passwordError;
	}	

}