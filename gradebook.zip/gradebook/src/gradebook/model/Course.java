package gradebook.model;

import java.io.Serializable;

public class Course implements Serializable {
	
	private static final long serialVersionUID = 2L;
	
	private int ID;
	private String name;
	private String number;
	private String IDAsString;
	
	public void setCourse(int ID, String name, String number) {
		this.ID = ID;
		this.name = name;
		this.number = number;
	}
	public int getID() {
		return ID;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getIDAsString() {
		return IDAsString;
	}
	public void setIDAsString(String iDAsString) {
		IDAsString = iDAsString;
	}	
}
