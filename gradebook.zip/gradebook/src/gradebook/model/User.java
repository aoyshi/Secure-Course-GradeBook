package gradebook.model;

import gradebook.BCrypt.BCrypt;
import gradebook.data.UserDAO;
import gradebook.validator.Validator;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class User implements Serializable {	
	
	private static final long serialVersionUID = 5L;
	private Validator validator = new Validator();
	
	@NotNull
	@Pattern(regexp = "^(0?[1-9]|[1-9][0-9])$")
	private int ID;	

	@NotNull
	@Pattern(regexp = "^[a-zA-Z]{2,30}$")
	private String firstName;
	
	@NotNull
	@Pattern(regexp = "^[a-zA-Z]{2,30}$")
	private String lastName;
	
	@NotNull
	@Pattern(regexp = "^[0-9]{10}$")
    private String utaID;
	
	@NotNull
	@Pattern(regexp = "^(Student|Professor)$")
    private String role;
	
	@NotNull
	@Pattern(regexp = "^([a-z]{3})([0-9]{4})$")
    private String netID;
	
	@NotNull
	@Pattern(regexp = "^(Student|Professor)$")
	
	@NotNull
	@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@._#$%^&+=]).{8,40}$")
	private String password;
		
	
	public int getID() { 
		return ID; 
	}		
	public void setID(int ID) { 
		this.ID=ID; 
	}	 	
	public String getNetID() { 
		return netID; 
	}
	public void setNetID(String netID) { 
		this.netID = netID; 
	}
	public String getUtaID() { 
		return utaID; 
	}	
	public void setUtaID(String utaID) { 
		this.utaID=utaID; 
	}	
	public String getFirstName() { 
		return firstName; 
	}
	public void setFirstName(String firstName) { 
		this.firstName=firstName; 
	}	
	public String getLastName() { 
		return lastName; 
	}
	public void setLastName(String lastName) { 
		this.lastName=lastName; 
	}	
	public String getPassword() { 
		return password; 
	}
	public void setPassword(String password){ 
		this.password=password; 
	}	
	public String getRole() { 
		return role; 
	}
	public void setRole(String role) { 
		this.role=role; 
	}
	
	/************ VERIFY LOGIN *************/	
	public void authenticateUser (User user, UserErrorMsgs errorMsgs) {	
		errorMsgs.setNetIDError(verifyNetID(user.getNetID()));
		errorMsgs.setPasswordError(verifyPassword(user.getPassword()));
		errorMsgs.setErrorMsg();
	}
	private String verifyNetID(String netID) {
		String result="";
		
		//do input validation of netID
		if(validator.validateNetID(netID)) {
			netID = netID.trim();
			if (netID.isEmpty()) {
				result = "NetID cannot be blank";
			} else {
				if (UserDAO.getUser(netID)==null) {
					result="This NetID is not registered yet";
				}
			}
		}
		else {
			result="Malformed NetID entered";
		}
					
		return result;				
	}
	private String verifyPassword(String passwordEntered) {
		String result="";
		
		//do input validation of password
		if(validator.validatePassword(password)) {
			if (passwordEntered.isEmpty()) {
				result = "Password cannot be blank";
			} else {
				User dbUser = UserDAO.getUser(netID);
				if (dbUser!=null) {
					String hashedPW = dbUser.getPassword();								
					if (!BCrypt.checkpw(passwordEntered,hashedPW)) {
						result="Incorrect password";
					}
				}
			}	
		}
		else {
			result="Malformed password entered";
		}
		return result;	
	}		

}