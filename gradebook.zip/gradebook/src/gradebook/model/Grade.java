package gradebook.model;

import java.io.Serializable;

public class Grade implements Serializable {
	
	private static final long serialVersionUID = 3L;
	
	private int studentID;
	private int courseID;
	private String letterGrade;

	public Grade (int studentID, int courseID, String letterGrade) {
		this.studentID = studentID;
		this.courseID = courseID;
		this.letterGrade = letterGrade;
	}	
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public int getCourseID() {
		return courseID;
	}
	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}
	public String getLetterGrade() {
		return letterGrade;
	}
	public void setLetterGrade(String letterGrade) {
		this.letterGrade = letterGrade;
	}
	
	public String validateGrade() {
		String result = "";
		if(!letterGrade.equals("A") && !letterGrade.equals("B") && !letterGrade.equals("C")
				&& !letterGrade.equals("D") && !letterGrade.equals("F") && !letterGrade.equals("W")
				&& !letterGrade.equals("None"))
			result="Invalid grade";
		return result;
	}
}