package gradebook.model;

import java.io.Serializable;

public class MyGrades implements Serializable {
	
	private static final long serialVersionUID = 4L;
	
	private String courseName;
	private String courseNumber;
	private String letterGrade;

	public MyGrades (String courseName, String courseNumber, String letterGrade) {
		this.courseName = courseName;
		this.courseNumber = courseNumber;
		this.letterGrade = letterGrade;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseNumber() {
		return courseNumber;
	}

	public void setCourseNumber(String courseNumber) {
		this.courseNumber = courseNumber;
	}

	public String getLetterGrade() {
		return letterGrade;
	}

	public void setLetterGrade(String letterGrade) {
		this.letterGrade = letterGrade;
	}	

}