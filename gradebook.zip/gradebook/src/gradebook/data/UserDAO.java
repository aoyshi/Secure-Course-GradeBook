package gradebook.data;

import gradebook.model.Course;
//TODO: alphabetical order
import gradebook.model.User;
import gradebook.util.SQLConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.PreparedStatement;

import java.sql.SQLException;

public class UserDAO {

	static SQLConnection DBMgr = SQLConnection.getInstance();
	
	//get a user based on netID (needed for login)
	public static User getUser(String netID) {
		PreparedStatement preparedStmt = null;   
		Connection conn = null;  
		User user = null;
		try {   
			conn = SQLConnection.getDBConnection();
			String query = "SELECT * from USER WHERE netID=? ;";
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setString(1, netID);
						
			ResultSet userList = preparedStmt.executeQuery();			
			if(!userList.next()) {
				//no rows found
			} else if(!userList.isLast()) {
				//more than 1 row found (expected unique)
				//TODO: log this
			} else {
				user = new User();
				String firstName  = userList.getString("firstName");
				String lastName  = userList.getString("lastName");
				String password = userList.getString("password");
				String role  = userList.getString("role");
				String utaID = userList.getString("utaID");
				int ID  = userList.getInt("ID");					
				//set User
				user.setID(ID);
				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setNetID(netID);
				user.setPassword(password);
				user.setRole(role);
				user.setUtaID(utaID);
			}
		} catch (SQLException e) {
			e.printStackTrace(); //TODO: log, error page
		} finally {
			try {
				if(conn!=null)
					conn.close(); 
			    if(preparedStmt!=null)	
			    	preparedStmt.close();
			} catch (SQLException e) {
				e.printStackTrace(); //TODO: log, error page
			}};
		return user;
	}
	
	//get a user based on utaID (needed for update grade)
		public static User getUserByUTAID(String utaID) {
			PreparedStatement preparedStmt = null;   
			Connection conn = null;  
			User user = null;
			try {   
				conn = SQLConnection.getDBConnection();
				String query = "SELECT * from USER WHERE utaID=? ;";
				preparedStmt = conn.prepareStatement(query);
				preparedStmt.setString(1, utaID);
							
				ResultSet userList = preparedStmt.executeQuery();			
				if(!userList.next()) {
					//no rows found
				} else if(!userList.isLast()) {
					//more than 1 row found (expected unique)
					//TODO: log this
				} else {
					user = new User();
					String firstName  = userList.getString("firstName");
					String lastName  = userList.getString("lastName");
					String password = userList.getString("password");
					String role  = userList.getString("role");
					String netID = userList.getString("netID");
					int ID  = userList.getInt("ID");					
					//set User
					user.setID(ID);
					user.setFirstName(firstName);
					user.setLastName(lastName);
					user.setNetID(netID);
					user.setPassword(password);
					user.setRole(role);
					user.setUtaID(utaID);
				}
			} catch (SQLException e) {
				e.printStackTrace(); //TODO: log, error page
			} finally {
				try {
					if(conn!=null)
						conn.close(); 
				    if(preparedStmt!=null)	
				    	preparedStmt.close();
				} catch (SQLException e) {
					e.printStackTrace(); //TODO: log, error page
				}};
			return user;
		}			
}