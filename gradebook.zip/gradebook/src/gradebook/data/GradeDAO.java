package gradebook.data;

import gradebook.model.AllGrades;
import gradebook.model.Course;
import gradebook.model.Grade;
import gradebook.model.MyGrades;
import gradebook.model.User;
import gradebook.util.SQLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class GradeDAO {
	
	static SQLConnection DBMgr = SQLConnection.getInstance();
	
	public static ArrayList<MyGrades> getMyGradesList(User student) {
		ArrayList<MyGrades> myGradesList = new ArrayList<MyGrades>();	
		PreparedStatement preparedStmt = null;   
		Connection conn = null;  	
		try {   
			conn = SQLConnection.getDBConnection();  
			String query = "SELECT course.name as name, course.number as number, letterGrade as grade FROM course,grade "
					+ "WHERE studentID=? and course.ID=grade.courseID;";
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setInt(1, student.getID());
			
			ResultSet courseListInDB = preparedStmt.executeQuery();
			while(courseListInDB.next()) {
				String name = courseListInDB.getString("name");
				String number  = courseListInDB.getString("number");
				String letterGrade  = courseListInDB.getString("grade");				
				MyGrades myGrade = new MyGrades(name,number,letterGrade);
				myGradesList.add(myGrade);
			}		
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null)
					conn.close(); 
			    if(preparedStmt!=null)	
			    	preparedStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return myGradesList;
	}
	
	public static ArrayList<AllGrades> getAllGradesList(int courseID) {
		ArrayList<AllGrades> allGradesList = new ArrayList<AllGrades>();	
		PreparedStatement preparedStmt = null;    
		Connection conn = null;  	
		try {   
			conn = SQLConnection.getDBConnection();  
			String query = "SELECT firstName,lastName,utaID,letterGrade as grade FROM user,grade " +
			"WHERE  courseID=? and grade.studentID=user.ID;";
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setInt(1, courseID);
			
			ResultSet courseListInDB = preparedStmt.executeQuery();
			while(courseListInDB.next()) {
				String firstName = courseListInDB.getString("firstName");
				String lastName  = courseListInDB.getString("lastName");
				String utaID  = courseListInDB.getString("utaID");
				String letterGrade  = courseListInDB.getString("grade");
				
				AllGrades eachGrade = new AllGrades(firstName,lastName,utaID,letterGrade);
				allGradesList.add(eachGrade);
			}		
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(conn!=null)
					conn.close(); 
			    if(preparedStmt!=null)	
			    	preparedStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return allGradesList;
	}
	
	
	public static void updateGrade(Grade grade) {
		PreparedStatement preparedStmt = null; 
		Connection conn = null; 	
		try {   
			conn = SQLConnection.getDBConnection(); 
			String updateQuery = "UPDATE grade SET letterGrade=? WHERE studentID=? and courseID=? ;";
			preparedStmt = conn.prepareStatement(updateQuery);
			preparedStmt.setString(1, grade.getLetterGrade());
			preparedStmt.setInt(2, grade.getStudentID());
			preparedStmt.setInt(3, grade.getCourseID());
			preparedStmt.executeUpdate();
			conn.commit();
					 
		} catch (SQLException sqle) { 
			sqle.printStackTrace();
		} finally {
			try {
				if(conn!=null)
					conn.close(); 
			    if(preparedStmt!=null)	
			    	preparedStmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			};
		}
	} 
}