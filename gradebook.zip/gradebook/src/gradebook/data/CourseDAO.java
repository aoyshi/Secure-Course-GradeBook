package gradebook.data;

import gradebook.model.Course;
import gradebook.model.User;
import gradebook.util.SQLConnection;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CourseDAO { 
	
	static SQLConnection DBMgr = SQLConnection.getInstance();
	 	
	public static Course getCourse(int courseID) {
		PreparedStatement preparedStmt = null;   
		Connection conn = null; 
		Course course = new Course();
		try {   
			conn = SQLConnection.getDBConnection();  
			String query = "SELECT * FROM course where ID = ? ;";
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setInt(1, courseID);
			
			ResultSet courseListInDB = preparedStmt.executeQuery();
			while(courseListInDB.next()) {
				int ID = courseListInDB.getInt("ID");
				String name = courseListInDB.getString("name");
				String number  = courseListInDB.getString("number");						
				course.setCourse(ID,name,number);
			}	

		} catch (SQLException e) {
			e.printStackTrace(); //TODO: log this, then error page
		} finally {
			try {
				if(conn!=null)
					conn.close(); 
			    if(preparedStmt!=null)	
			    	preparedStmt.close();
			} catch (SQLException e) {
				e.printStackTrace(); //TODO: log this, then error page
			}};
		return course;
	}
	
	public static ArrayList<Course> getProfessorCourseList(User professor) {
		ArrayList<Course> courseList = new ArrayList<Course>();	
		PreparedStatement preparedStmt = null;   
		Connection conn = null;  	
		try {   
			conn = SQLConnection.getDBConnection();  
			String query = "SELECT course.ID as ID, course.name as name, course.number as number "
					+ "FROM professor,course WHERE professorID=? and course.ID=professor.courseID ;";
			preparedStmt = conn.prepareStatement(query);
			preparedStmt.setInt(1, professor.getID());
						
			ResultSet courseListInDB = preparedStmt.executeQuery();
			while(courseListInDB.next()) {
				int ID = courseListInDB.getInt("ID");
				String name = courseListInDB.getString("name");
				String number  = courseListInDB.getString("number");						
				Course course = new Course();
				course.setCourse(ID,name,number);
				courseList.add(course);
			}		
		} catch (SQLException e) {
			e.printStackTrace(); //TODO: log this, then error page
		} finally {
			try {
				if(conn!=null)
					conn.close(); 
			    if(preparedStmt!=null)	
			    	preparedStmt.close();
			} catch (SQLException e) {
				e.printStackTrace(); //TODO: log this, then error page
			}};
		return courseList;
	}	
}
