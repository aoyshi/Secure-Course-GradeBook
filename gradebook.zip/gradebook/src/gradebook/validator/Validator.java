package gradebook.validator;

import gradebook.model.User;

public class Validator {
	
	public boolean validateAction(String action) {
//		if(action.length()==0 || action.length()>=50 || action==null || !action.matches("[a-zA-Z]+")) {
//			return false;
//		}
//		else {
//			return true;
//		}
		return true;
	}
	
	public boolean validateNetID(String netID) {
//		if(netID.length()!=7 || netID==null || !netID.matches("^([a-z]{3})([0-9]{4})$")) {
//			return false; 
//		}
//		else {
//			return true;
//		}
		return true;
	}
	
	public boolean validatePassword(String password) {				
//		if(!password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@._#$%^&+=]).{8,40}$")) {
//			return false;
//		}
//		else {
//			return true;
//		}
		return true;
	}

	public boolean validateUser(User user) {
//		if (validateNetID(user.getNetID()) && validatePassword(user.getPassword())) {
//			return true;
//		}
//		else {
//			return false;
//		}
		return true;
	}

}
